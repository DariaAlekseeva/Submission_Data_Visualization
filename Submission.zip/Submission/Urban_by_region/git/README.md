To see visualization in the browser check [this link](http://bl.ocks.org/DariaAlekseeva/raw/fde6999e69da2158ade6/)  

##Design
I combined two chart types: bubble chart and bar chart. Bubble chart is good to display 3 variables at once.   
X axis is for GDP per capita. GDP per capita increases with years and theoretically GDP per capita is unbounded.  
Y is for Urban population in percent, and its maximum is 100%.  
I chose unbounded value for X and bounded value for Y since it's easier to view on wide screens like PC screen.  
I chose Bubble plot since it is good for displaying linear relationship between X and Y. GDP gap among countries is quite big so to keep linear relation between X and Y I used log scale on X axis.  
Legend includes regions and users can filter the data by clicking on any region.  
Grouping by region is good for visualization because we may cluster countries by region.  
Bar plot on the right hand side runs automatically after page is loaded.  
Years run from 1960 to 2010 displaying the world development in the last 50 years.  
I picked 5 years time interval to keep time bar not crowded and to see changes better for each country/region.  
Size of bar shows total GDP per capita in particular year. For example, one can notice that total GDP per capita almost didn't change between 1980 and 1985. The same conclusion could be achieved from the bubble chart and reader can explore each country or region separately.  
When first round is completed animation stops automatically and reader may explore the chart by clicking any year and/or legend. Categorical variable "region" displayed in contrast colours to make the difference between groups clear.  

## The story  

My story comes from an [article from New York Times](http://www.nytimes.com/2010/12/19/magazine/19Urban_West-t.html?_r=0) and BBC Documentary The Code. It is suggested that cities exist because cities increase efficiency and people become better off by 15% by when the city population doubles. This means a person living in a city earn 15% more, get 15% better healthcare service etc.. than a person lives in a city with half population. This is a very interesting topic and I wanted to explore this idea by looking at the last half century of economic development and urbanization in the world.  
There is a trend of migration from rural areas to cities and urban population grows. People get better access to healthcare services, economy develops and as a result they live longer. But not all countries/regions grow with the same pace. We can see how world economy develops. Sometimes with a rapid pace and other times with slower pace. Despite the world economy grows couple of countries move to opposite direction in some years. This is interesting and worth to explore further.     

My assumption was GDP per capita, life expectancy and urbanization rate would increase altogether. This is confirmed by looking at the chart.  The chart suggests that there is a correlation between urbanization and GDP per capita. All countries shifted from left to right along X axis as their GDP per capita increased. African counties have the worst economy and lowest urbanization levels in general. However with the time, gap between developed countries and the underdeveloped countries grew. Please note that X axis is in log and shifting to the right means increasing the gap. In XIX century economy levels were closer than it is now. Also the speed of economic growth is much higher in developed countries.   
Countries tend to shift in +Y direction as time passes. This explains urbanization is increasing in all regions. Europe, South and North America have higher urban population rate than other continents. Life expectancy (displayed by bubble size) grows with both urban population and GDP per capita: again Africa has the lowest levels, Europe - higher in average.   
Even though Asia has a very wide spectrum of countries most urbanized countries are still in Asia: Hong Kong and Singapore.   Singapore and Hong Kong confirm the initial idea that urbanization and higher income/better life expectancy all are positively proportional. Similarly countries in Africa and some countries in Asia has very low urbanization rate and thus low GDP per capita and low life expectancy. 
  
Mostly countries from one group stay clustered. In this sense Oceania (and same applies to Asia) is an interesting region. There is Australia with high GDP, life expectancy and urban population rate in one end and there is Papua New Guinea with low GDP low life expectancy and low urbanization rate.  
  
Africa was concentrated in the very bottom in 1960 but in 2010 this region is very much spread. Gabon's economy grew quite a lot but Burundi still in bad condition.  

A close up look into countries those move in the opposite direction of the general trend are telling us also very interesting stories. A few of them are below:   
Chile moved left on the chart between 1970 and 1975. This marks the event of military coup in 1973.   
Uganda moved left sharply between 1975 and 1980. Uganda was in war with Tanzania in 1978 and 1979.  
Nicaragua, Sierra Leone and Liberia had conflicts in 1980s to 1990s and these countries move to the opposite direction in these years.  
Gabon is a success story. We notice a big advancement in Gabon economy between 1970-1975. This is inline whit the dicovery of oil in Gabon in 1971. 


There are still very many thing to say about regions and each country separately. I hope the reader will enjoy this plot!  

##Resources
The data source for this visualization is [here](http://databank.worldbank.org/data/home.aspx).  
http://dimplejs.org/  
https://github.com/PMSI-AlignAlytics/dimple/wiki/dimple.axis  