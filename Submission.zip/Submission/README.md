To see visualization in the browser check [this link](http://bl.ocks.org/DariaAlekseeva/raw/47a1cae911b579d1d4de/).  
Link to my Gist [repo](https://gist.github.com/DariaAlekseeva/47a1cae911b579d1d4de)

#Process of creation  
From my point of view social development of countries is an interesting topic to explore and present to the audience. I picked bubble chart to represent the data as here we have got a power not just of X and Y but also Z as a bubble size. Adding bar plot on the right hand side let us switch between years and also see total GDP per capita for particular year.

##Step 1
Initially I plotted number of internet users (per 100 people) vs. life expectancy thinking that the higher life expectancy a country has the more internet users there are. It turned that at the beginning of XXI century life expectancy was already quite high and didn't change significantly almost all over the world and number of internet users grew more or less independently. It seems to me quite straightforward conclusion which doesn't deserve to be presented to the audience. 

**Files for step 1**  
- data.csv (source file from [here](http://databank.worldbank.org/data/views/reports/tableview.aspx?isshared=true))
- life_internet.Rmd  
- life_internet.tsv  
- index_internet_vs_life.html  
- internet_vs_life.png  

##Step 2

#### Improvements     
1. Changed variables into Women Labor Force participation rate vs Annual Population Growth.  
2. Y axis values (Annual Population Growth) and GDP per capita converted into float.   

####My initial assumptions were:  
1. Countries with higher GDP have higher women labor force rate.  
2. Women labor force rate increases with the time.  
3. Countries with higher population growth have lower women labor force.  
4. African countries have high population growth rate and low women labor force rate.  
5. Population growth becomes negative for countries in economic crisis or internal/external conflicts.  

####However some results surprised me. Looking at the visualization we can conclude that:  
1. Woman labor force rate stays quite the same in each country between 2005 and 2012.  
2. Countries with higher GDP have medium woman labor force rate (they are in the middle of the x-axis between 40% and 70%).  
3. There is no relation between population growth and woman labor force rate in the countries.  
4. African countries don't have high population growth rate but have very high women labor force rate.  
5. Population growth rate in some of arabic countries was pretty high before crisis 2008 and drastically dropped right after.  
6. Total GDP per capita in the world decreased after 2008 and came back to the same level only in 2011.  

**Files for step 2**  
- data.csv (source file from [here](http://databank.worldbank.org/data/views/reports/tableview.aspx?isshared=true))
- data1.csv (source file from [here]())  
- data2.csv (source file)  
- pop_growth_woman_labor_v1.html  
- pop_growth_woman_labor.tsv  
- pop_growth_woman_labor.Rmd  
- pop_growth_woman_labor.csv  
- pop_growth_woman_labor.png  


##Step 3

###Feedback  
Please feel free to leave your feedback.  

- What do you notice in the visualization?  
- What questions do you have about the data?  
- What relationships do you notice?  
- What do you think is the main takeaway from this visualization?  
- Is there something you don’t understand in the graphic?  

#### [Feedback 1](http://discussions.udacity.com/t/please-post-feedback-on-my-visualization/14935)  
I suggest you do not update the scale on Y axis when the user filter different years. It would make easier to follow how things changed throughout the years. I'm not sure, but it seems that there is no connection between color hue and the regions of each country. It would be useful if you encode these informations on your chart.  

#### Feedback 2  
1. What do you notice in the visualization?  
Mostly Middle Eastern and North African countries have the lower rates of women labour in contrast to South and Central African countries have the highest rates. The main reasons behind these results seems religion and poverty respectively. I could not notice an obvious correlation between the women labour rate and the population growth, which seems interesting for me.  
2. What questions do you have about the data?  
The thing I wonder according to this graphic is; what are the wage rates of women according to men especially in the countries with a high rate of women labour?  
3. What relationships do you notice?  
Changes on global GDP per capita affects population growth rate not instantly but on the following years.  
4. What do you think is the main takeaway from this visualization?  
For this time period women labour rate per country is around 50%-60% and general trends about this topic has not changed.  
5. Is there something you don’t understand in the graphic?  
Graphic is fairly easy to understand. But a search option to highlight a specific country or an option to apply specific filters to group some variables make it much more interesting for the end users.  

#### Feedback 3  
Visually beautiful graphics, I like the unusual approach to the image statistics. The theme of the study is also very relevant. But I can not fix the schedule for a given year, the schedule is in motion all the time. Also, a little is not enough time to read the information in the frame.  

#### Feedback 4  
Currently there is a separate colour for each country. I'd say if would be much less messy and also more informative if we can group the countries using some criteria such as region, continent or religion. This makes sense since religion or geography has impact on birth rate or women work force rate. Also optionally if we can see the groups separately in the graph would be nice since about 200 or so countries makes the mid part of the graph very crowded. Filtering based on the options I mentioned above would keep the graph clean and organized.   

#### Changes after feedback  
I found very useful the process of collecting feedbacks. People gave very nice ideas about improvement and I was able to take them and make changes. They are the following:  
1. Set up fixed values for x and y axis for easier comprehension.  
2. Added region and religion groups.  
3. Bubbles are coloured according to religion group.  
4. Added flexible legend so it's possible to hide/pick particular religion groups.   


**Files for step 3**  
- data.csv (source file)
- data1.csv (source file)  
- data2.csv (source file)  
- index.html  
- pop_growth_woman_labor_by_region.tsv  
- regions.csv  
- pop_growth_woman_labor_by_region.Rmd  
- regions.rmd  
- regions_raw.csv  


#Resources
The data source for this visualization is [here](http://databank.worldbank.org/data/home.aspx).  
http://dimplejs.org/  
http://dimplejs.org/  
https://github.com/PMSI-AlignAlytics/dimple/wiki/dimple.axis  